# Exercício2

A Pen created on CodePen.

Original URL: [https://codepen.io/VanessaFranca/pen/qEOvjZP](https://codepen.io/VanessaFranca/pen/qEOvjZP).

